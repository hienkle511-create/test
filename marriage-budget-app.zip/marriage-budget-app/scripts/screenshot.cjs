// CommonJS on purpose: ESM `import` resolution of the symlinked
// `playwright` package hits a quirk in this sandbox's filesystem layer
// (lstat reports the node_modules/playwright symlink as a regular
// non-symlink entry, breaking Node's ESM package resolver) even though
// CJS `require.resolve` handles the same symlink fine. Using require()
// here sidesteps that entirely.
const { chromium } = require("playwright");
const path = require("path");

const outDir = path.join(__dirname, "..", "screenshots");

const pages = [
  { path: "/", file: "dashboard.png" },
  { path: "/transactions", file: "transactions.png" },
  { path: "/budgets", file: "budgets.png" },
  { path: "/categories", file: "categories.png" },
];

async function main() {
  let browser;
  try {
    browser = await chromium.launch();
  } catch (e) {
    console.log("Default launch failed, trying explicit executablePath...", e.message);
    browser = await chromium.launch({ executablePath: "/opt/pw-browsers/chromium" });
  }
  const context = await browser.newContext({ viewport: { width: 1440, height: 1000 } });
  const page = await context.newPage();

  for (const { path: p, file } of pages) {
    await page.goto(`http://localhost:3000${p}`, { waitUntil: "networkidle" });
    if (p === "/transactions") {
      const toggle = await page.$("[data-toggle]");
      if (toggle) await toggle.click();
      await page.waitForTimeout(150);
    }
    await page.screenshot({ path: path.join(outDir, file), fullPage: false });
    console.log(`Captured ${file}`);
  }

  await browser.close();
}

main().catch((e) => {
  console.error(e);
  process.exit(1);
});
