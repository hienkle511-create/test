// Bundles the small client-side interactivity scripts with esbuild
// (esbuild is used here as a bundler only — see prisma/schema.prisma and
// src/server.tsx for why the full Next.js toolchain isn't installed).
import * as esbuild from "esbuild";
import path from "node:path";
import { fileURLToPath } from "node:url";

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const root = path.join(__dirname, "..");

await esbuild.build({
  entryPoints: [
    path.join(root, "src/client/transactions.ts"),
    path.join(root, "src/client/categories.ts"),
  ],
  outdir: path.join(root, "public"),
  bundle: true,
  minify: true,
  format: "esm",
  target: "es2020",
});

console.log("Client bundles built into public/.");
