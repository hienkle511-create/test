import React from "react";
import { SPLIT_COLORS, SPLIT_LABELS, type SplitType } from "../types.ts";
import { formatCurrencyShort } from "../lib/format.ts";
import type { CategoryRow } from "../types.ts";

// Hand-rolled Sankey renderer (no d3-sankey — see note in src/server.tsx on
// package-install limitations in this sandbox). Because every category
// belongs to exactly one split bucket, the layout is a simple two-stage tree
// (Income -> split bucket -> categories) with no crossing flows, which we
// can lay out and ribbon directly without a general Sankey solver.
//
// Node heights are proportional to dollar value but clamped to a minimum
// pixel height (like d3-sankey's nodeHeight floor) so small personal-spend
// slices stay legible; the SVG's total height grows to fit whatever that
// clamping produces rather than using a fixed canvas size.

const ORDER: SplitType[] = ["JOINT", "PERSONAL_KRISSY", "PERSONAL_HUSBAND", "BABY"];
const SAVINGS_COLOR = "#94a3b8";
const MIN_BUCKET_H = 34;
const MIN_CAT_H = 15;
const BUCKET_GAP = 20;
const CAT_GAP = 5;

interface SankeyProps {
  totalIncome: number;
  savings: number;
  spendBySplit: Map<SplitType, number>;
  spendByCategoryPerSplit: Map<string, Map<string, number>>;
  categoryMap: Map<string, CategoryRow>;
}

function ribbonPath(x0: number, y0a: number, y0b: number, x1: number, y1a: number, y1b: number) {
  const midX = (x0 + x1) / 2;
  return [
    `M ${x0} ${y0a}`,
    `C ${midX} ${y0a} ${midX} ${y1a} ${x1} ${y1a}`,
    `L ${x1} ${y1b}`,
    `C ${midX} ${y1b} ${midX} ${y0b} ${x0} ${y0b}`,
    "Z",
  ].join(" ");
}

export function Sankey({ totalIncome, savings, spendBySplit, spendByCategoryPerSplit, categoryMap }: SankeyProps) {
  const W = 860;
  const PAD_TOP = 36;
  const PAD_BOTTOM = 24;
  const TARGET_COLUMN_H = 340; // baseline before min-height clamping expands it

  const bucketEntries: { splitType: SplitType | "SAVINGS"; value: number; color: string; label: string }[] = ORDER.filter(
    (s) => (spendBySplit.get(s) ?? 0) > 0
  ).map((s) => ({
    splitType: s,
    value: spendBySplit.get(s)!,
    color: SPLIT_COLORS[s],
    label: SPLIT_LABELS[s],
  }));
  if (savings > 0) {
    bucketEntries.push({ splitType: "SAVINGS", value: savings, color: SAVINGS_COLOR, label: "Savings" });
  }

  const totalOut = bucketEntries.reduce((s, b) => s + b.value, 0);

  if (totalOut <= 0) {
    return <div className="empty-state">No cash flow to visualize for this month yet.</div>;
  }

  const scale = Math.max(totalIncome, totalOut, 1);
  const pxPerDollar = TARGET_COLUMN_H / scale;

  // --- Column X positions ---
  const xIncome = 60;
  const xBucket = 380;
  const xCategory = 700;
  const nodeW = 14;

  // --- Pre-compute each bucket's category cluster (may force the bucket
  //     taller than its raw dollar-proportional height) ---
  const bucketCategoryInfo = bucketEntries.map((b) => {
    if (b.splitType === "SAVINGS") return { entries: [] as { name: string; amount: number; h: number }[], clusterH: 0 };
    const catMap = spendByCategoryPerSplit.get(b.splitType) ?? new Map();
    const entries = Array.from(catMap.entries())
      .map(([catId, amount]) => ({ name: categoryMap.get(catId)?.name ?? "Other", amount, h: Math.max(amount * pxPerDollar, MIN_CAT_H) }))
      .sort((a, c) => c.amount - a.amount);
    const clusterH = entries.reduce((s, e) => s + e.h, 0) + CAT_GAP * Math.max(0, entries.length - 1);
    return { entries, clusterH };
  });

  const bucketFinalH = bucketEntries.map((b, i) => Math.max(b.value * pxPerDollar, MIN_BUCKET_H, bucketCategoryInfo[i].clusterH));
  const bucketTotalHeight = bucketFinalH.reduce((s, h) => s + h, 0) + BUCKET_GAP * Math.max(0, bucketEntries.length - 1);

  const availH = bucketTotalHeight;
  const H = availH + PAD_TOP + PAD_BOTTOM;

  // --- Column 1: bucket nodes, stacked with gaps, centered ---
  let cursor = PAD_TOP;
  const buckets = bucketEntries.map((b, i) => {
    const h = bucketFinalH[i];
    const top = cursor;
    const bottom = top + h;
    cursor = bottom + BUCKET_GAP;
    return { ...b, top, bottom, h };
  });

  // --- Column 0: single Income node, same scale, vertically centered ---
  const incomeHeight = Math.min(totalIncome * pxPerDollar, availH);
  const incomeTop = PAD_TOP + (availH - incomeHeight) / 2;

  // --- Column 2: category nodes, centered within their bucket's final span ---
  const categoryNodes: { name: string; color: string; top: number; bottom: number; value: number }[] = [];
  buckets.forEach((b, i) => {
    const { entries } = bucketCategoryInfo[i];
    const clusterH = entries.reduce((s, e) => s + e.h, 0) + CAT_GAP * Math.max(0, entries.length - 1);
    let c = b.top + (b.h - clusterH) / 2;
    for (const e of entries) {
      categoryNodes.push({ name: e.name, color: b.color, top: c, bottom: c + e.h, value: e.amount });
      c += e.h + CAT_GAP;
    }
  });

  return (
    <svg width="100%" height={H} viewBox={`0 0 ${W} ${H}`} preserveAspectRatio="xMidYMid meet">
      <defs>
        {buckets.map((b, i) => (
          <linearGradient key={i} id={`flow-income-${i}`} x1="0" x2="1" y1="0" y2="0">
            <stop offset="0%" stopColor="#c7cad4" />
            <stop offset="100%" stopColor={b.color} />
          </linearGradient>
        ))}
      </defs>

      {/* Income -> Bucket ribbons (slice sized by each bucket's own value,
          scaled to fill the income node's edge proportionally) */}
      {(() => {
        let incomeCursor = incomeTop;
        return buckets.map((b, i) => {
          const sliceH = (b.value / totalOut) * incomeHeight;
          const y0a = incomeCursor;
          const y0b = incomeCursor + sliceH;
          incomeCursor = y0b;
          const d = ribbonPath(xIncome + nodeW, y0a, y0b, xBucket, b.top, b.bottom);
          return <path key={`ib-${i}`} d={d} fill={`url(#flow-income-${i})`} opacity={0.55} />;
        });
      })()}

      {/* Bucket -> Category ribbons */}
      {categoryNodes.map((c, i) => (
        <path
          key={`bc-${i}`}
          d={ribbonPath(xBucket + nodeW, c.top, c.bottom, xCategory, c.top, c.bottom)}
          fill={c.color}
          opacity={0.3}
        />
      ))}

      {/* Income node */}
      <rect x={xIncome} y={incomeTop} width={nodeW} height={incomeHeight} rx={3} fill="#334155" />
      <text x={xIncome - 8} y={incomeTop + incomeHeight / 2 - 6} textAnchor="end" fontSize="12.5" fontWeight="700" fill="#1f2430">
        Income
      </text>
      <text x={xIncome - 8} y={incomeTop + incomeHeight / 2 + 10} textAnchor="end" fontSize="11" fill="#6b7280">
        {formatCurrencyShort(totalIncome)}
      </text>

      {/* Bucket nodes */}
      {buckets.map((b, i) => (
        <g key={`bn-${i}`}>
          <rect x={xBucket} y={b.top} width={nodeW} height={b.h} rx={3} fill={b.color} />
          <text x={xBucket + nodeW / 2} y={b.top - 10} textAnchor="middle" fontSize="12" fontWeight="700" fill="#1f2430">
            {b.label}
          </text>
          <text x={xBucket + nodeW / 2} y={b.top + b.h / 2 + 4} textAnchor="middle" fontSize="10.5" fontWeight="700" fill="#ffffff" opacity={b.h > 20 ? 1 : 0}>
            {formatCurrencyShort(b.value)}
          </text>
        </g>
      ))}

      {/* Category nodes + labels */}
      {categoryNodes.map((c, i) => (
        <g key={`cn-${i}`}>
          <rect x={xCategory} y={c.top} width={nodeW} height={Math.max(c.bottom - c.top, 1.5)} rx={2.5} fill={c.color} />
          <text x={xCategory + nodeW + 8} y={(c.top + c.bottom) / 2 + 4} fontSize="11.5" fill="#1f2430">
            {c.name}
          </text>
          <text x={W - 8} y={(c.top + c.bottom) / 2 + 4} fontSize="11" fill="#9aa1b1" textAnchor="end">
            {formatCurrencyShort(c.value)}
          </text>
        </g>
      ))}
    </svg>
  );
}
