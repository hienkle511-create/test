import React from "react";
import { formatCurrency, formatCurrencyShort } from "../lib/format.ts";

const PALETTE = [
  "#22c55e", "#3b82f6", "#c084fc", "#f59e0b", "#f472b6",
  "#14b8a6", "#f97316", "#6366f1", "#84cc16", "#ef4444",
  "#0ea5e9", "#a855f7", "#eab308", "#10b981",
];

export function Donut({ data }: { data: { name: string; amount: number }[] }) {
  const total = data.reduce((s, d) => s + d.amount, 0);
  if (total <= 0 || data.length === 0) {
    return <div className="empty-state">No spending recorded this month yet.</div>;
  }
  const R = 60;
  const STROKE = 26;
  const CIRC = 2 * Math.PI * R;
  let cumulative = 0;

  const arcs = data.map((d, i) => {
    const frac = d.amount / total;
    const dash = Math.max(frac * CIRC - 2, 0);
    const gap = CIRC - dash;
    const offset = -cumulative * CIRC;
    cumulative += frac;
    return { color: PALETTE[i % PALETTE.length], dash, gap, offset, name: d.name, amount: d.amount, frac };
  });

  return (
    <div style={{ display: "flex", gap: 24, alignItems: "center" }}>
      <svg width="160" height="160" viewBox="0 0 160 160" style={{ flexShrink: 0 }}>
        <g transform="translate(80,80) rotate(-90)">
          <circle r={R} fill="none" stroke="#eef0f5" strokeWidth={STROKE} />
          {arcs.map((a, i) => (
            <circle
              key={i}
              r={R}
              fill="none"
              stroke={a.color}
              strokeWidth={STROKE}
              strokeDasharray={`${a.dash} ${a.gap}`}
              strokeDashoffset={a.offset}
              strokeLinecap="butt"
            />
          ))}
        </g>
        <text x="80" y="76" textAnchor="middle" fontSize="11" fill="#9aa1b1" fontWeight="600">
          TOTAL SPEND
        </text>
        <text x="80" y="96" textAnchor="middle" fontSize="17" fill="#1f2430" fontWeight="700">
          {formatCurrencyShort(total)}
        </text>
      </svg>
      <div style={{ display: "flex", flexDirection: "column", gap: 8, flex: 1, minWidth: 0 }}>
        {arcs.slice(0, 7).map((a, i) => (
          <div key={i} style={{ display: "flex", alignItems: "center", gap: 8, fontSize: 12.5 }}>
            <span style={{ width: 9, height: 9, borderRadius: 3, background: a.color, flexShrink: 0 }} />
            <span style={{ flex: 1, color: "#1f2430", overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>
              {a.name}
            </span>
            <span style={{ color: "#6b7280", fontVariantNumeric: "tabular-nums" }}>{formatCurrency(a.amount)}</span>
            <span style={{ color: "#9aa1b1", width: 34, textAlign: "right" }}>{Math.round(a.frac * 100)}%</span>
          </div>
        ))}
      </div>
    </div>
  );
}
