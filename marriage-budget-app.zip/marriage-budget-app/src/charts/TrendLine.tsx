import React from "react";
import { formatCurrencyShort, monthShortLabel } from "../lib/format.ts";

export function TrendLine({ data }: { data: { month: string; income: number; expense: number }[] }) {
  const W = 560;
  const H = 220;
  const PAD_L = 46;
  const PAD_B = 28;
  const PAD_T = 16;
  const PAD_R = 12;
  const innerW = W - PAD_L - PAD_R;
  const innerH = H - PAD_T - PAD_B;

  const maxVal = Math.max(1, ...data.map((d) => Math.max(d.income, d.expense))) * 1.15;
  const x = (i: number) => PAD_L + (innerW * i) / Math.max(1, data.length - 1);
  const y = (v: number) => PAD_T + innerH - (innerH * v) / maxVal;

  const pathFor = (key: "income" | "expense") =>
    data.map((d, i) => `${i === 0 ? "M" : "L"} ${x(i).toFixed(1)} ${y(d[key]).toFixed(1)}`).join(" ");

  const ticks = 4;
  const gridLines = Array.from({ length: ticks + 1 }, (_, i) => {
    const v = (maxVal / ticks) * i;
    return { v, yy: y(v) };
  });

  return (
    <svg width="100%" height={H} viewBox={`0 0 ${W} ${H}`} preserveAspectRatio="xMidYMid meet">
      {gridLines.map((g, i) => (
        <g key={i}>
          <line x1={PAD_L} x2={W - PAD_R} y1={g.yy} y2={g.yy} stroke="#eef0f5" strokeWidth={1} />
          <text x={PAD_L - 8} y={g.yy + 4} fontSize="10.5" textAnchor="end" fill="#9aa1b1">
            {formatCurrencyShort(g.v)}
          </text>
        </g>
      ))}

      {data.map((d, i) => (
        <text key={i} x={x(i)} y={H - 6} fontSize="11" textAnchor="middle" fill="#9aa1b1">
          {monthShortLabel(d.month)}
        </text>
      ))}

      <path d={pathFor("income")} fill="none" stroke="#22c55e" strokeWidth={2.5} strokeLinejoin="round" strokeLinecap="round" />
      <path d={pathFor("expense")} fill="none" stroke="#f59e0b" strokeWidth={2.5} strokeLinejoin="round" strokeLinecap="round" strokeDasharray="0" />

      {data.map((d, i) => (
        <g key={`dots-${i}`}>
          <circle cx={x(i)} cy={y(d.income)} r={3.5} fill="#22c55e" />
          <circle cx={x(i)} cy={y(d.expense)} r={3.5} fill="#f59e0b" />
        </g>
      ))}
    </svg>
  );
}
