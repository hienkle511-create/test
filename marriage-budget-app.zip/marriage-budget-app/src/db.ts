// Thin data-access layer over Node's built-in node:sqlite (experimental).
// Stands in for `@prisma/client` in this sandbox build — see the note at
// the top of prisma/schema.prisma for why.
import { DatabaseSync } from "node:sqlite";
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";

const __dirname = path.dirname(fileURLToPath(import.meta.url));
// Optional override so a deploy can point the SQLite file at a persistent
// volume (e.g. Railway) instead of the project directory. See README.md's
// "Deploying" section. Defaults to the same in-repo path as before when
// DB_PATH isn't set, so local dev behavior is unchanged.
const DB_PATH = process.env.DB_PATH ?? path.join(__dirname, "..", "dev.db");
const SCHEMA_PATH = path.join(__dirname, "schema.sql");

export const db = new DatabaseSync(DB_PATH);
db.exec("PRAGMA foreign_keys = ON;");

export function initSchema() {
  const ddl = fs.readFileSync(SCHEMA_PATH, "utf-8");
  db.exec(ddl);
}

export function all<T = any>(sql: string, params: any[] = []): T[] {
  const stmt = db.prepare(sql);
  return stmt.all(...params) as T[];
}

export function one<T = any>(sql: string, params: any[] = []): T | undefined {
  const stmt = db.prepare(sql);
  return stmt.get(...params) as T | undefined;
}

export function run(sql: string, params: any[] = []) {
  const stmt = db.prepare(sql);
  return stmt.run(...params);
}

initSchema();
