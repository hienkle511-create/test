import React from "react";
import { formatCurrency } from "../lib/format.ts";

export function budgetStatus(actual: number, budget: number): "ok" | "amber" | "red" {
  if (budget <= 0) return "ok";
  const pct = actual / budget;
  if (pct >= 1) return "red";
  if (pct >= 0.85) return "amber";
  return "ok";
}

export function BudgetProgressRow({
  name,
  budget,
  actual,
}: {
  name: string;
  budget: number;
  actual: number;
}) {
  const pct = budget > 0 ? Math.min(100, (actual / budget) * 100) : 0;
  const status = budgetStatus(actual, budget);
  return (
    <div className="budget-row">
      <div className="budget-row-head">
        <span className="budget-row-name">
          {name}
          {status !== "ok" ? (
            <span className={`budget-status ${status}`}>{status === "red" ? "OVER" : "NEAR LIMIT"}</span>
          ) : null}
        </span>
        <span className="budget-row-nums">
          <strong>{formatCurrency(actual)}</strong> / {formatCurrency(budget)}
        </span>
      </div>
      <div className="progress-track">
        <div className={`progress-fill ${status}`} style={{ width: `${pct}%` }} />
      </div>
    </div>
  );
}
