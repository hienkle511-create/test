import React from "react";
import type { SplitType } from "../types.ts";
import { SPLIT_LABELS } from "../types.ts";

export function SplitBadge({ splitType }: { splitType: SplitType }) {
  const cls = `badge badge-${splitType.toLowerCase()}`;
  return (
    <span className={cls}>
      <span className="badge-dot" />
      {SPLIT_LABELS[splitType]}
    </span>
  );
}
