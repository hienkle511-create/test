import React from "react";

export function Card({
  title,
  right,
  children,
  style,
}: {
  title?: string;
  right?: React.ReactNode;
  children: React.ReactNode;
  style?: React.CSSProperties;
}) {
  return (
    <div className="card" style={style}>
      {title ? (
        <div className="card-title-row">
          <div className="card-title">{title}</div>
          {right}
        </div>
      ) : null}
      {children}
    </div>
  );
}
