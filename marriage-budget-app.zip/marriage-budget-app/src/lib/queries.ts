import { all, one } from "../db.ts";
import type {
  AccountRow,
  BudgetRow,
  CategoryRow,
  ReceiptRow,
  SplitType,
  TransactionRow,
  TransactionSplitRow,
} from "../types.ts";

export const CURRENT_MONTH = "2026-08";

export function getCategories(): CategoryRow[] {
  return all<CategoryRow>(`SELECT id, householdId, name, "group" FROM Category ORDER BY "group", name`);
}

export function getCategoryMap(): Map<string, CategoryRow> {
  const map = new Map<string, CategoryRow>();
  for (const c of getCategories()) map.set(c.id, c);
  return map;
}

export function getAccounts(): AccountRow[] {
  return all<AccountRow>(`SELECT * FROM Account ORDER BY name`);
}

export function getReceiptMap(): Map<string, ReceiptRow> {
  const rows = all<ReceiptRow>(`SELECT * FROM Receipt`);
  const map = new Map<string, ReceiptRow>();
  for (const r of rows) map.set(r.id, r);
  return map;
}

export interface LineItem {
  date: string;
  merchant: string;
  amount: number;
  categoryId: string;
  splitType: SplitType;
  parentId: string;
}

// Flattens Transactions + their itemized TransactionSplits into a single
// list of "line items" for reporting, so a receipt with children is counted
// once via its splits rather than double-counted against its parent.
export function getLineItems(): LineItem[] {
  const txns = all<TransactionRow>(`SELECT * FROM "Transaction"`);
  const splits = all<TransactionSplitRow>(`SELECT * FROM TransactionSplit`);
  const splitsByParent = new Map<string, TransactionSplitRow[]>();
  for (const s of splits) {
    const arr = splitsByParent.get(s.parentTransactionId) ?? [];
    arr.push(s);
    splitsByParent.set(s.parentTransactionId, arr);
  }
  const items: LineItem[] = [];
  for (const t of txns) {
    const children = splitsByParent.get(t.id);
    if (children && children.length > 0) {
      for (const s of children) {
        items.push({ date: t.date, merchant: t.merchant, amount: s.amount, categoryId: s.categoryId, splitType: s.splitType, parentId: t.id });
      }
    } else {
      items.push({ date: t.date, merchant: t.merchant, amount: t.amount, categoryId: t.categoryId, splitType: t.splitType, parentId: t.id });
    }
  }
  return items;
}

const inMonth = (date: string, month: string) => date.startsWith(month);

export function getSummaryCards(month: string = CURRENT_MONTH) {
  const accounts = getAccounts();
  const netCash = accounts.reduce((sum, a) => sum + a.balance, 0);

  const items = getLineItems().filter((li) => inMonth(li.date, month));
  const categoryMap = getCategoryMap();
  const spendItems = items.filter((li) => {
    const cat = categoryMap.get(li.categoryId);
    return cat?.group !== "Income" && li.amount < 0;
  });
  const thisMonthSpend = -spendItems.reduce((sum, li) => sum + li.amount, 0);

  const budgets = all<BudgetRow>(`SELECT * FROM Budget WHERE month = ?`, [month]);
  const totalBudget = budgets.reduce((sum, b) => sum + b.amount, 0);
  const budgetRemaining = totalBudget - thisMonthSpend;

  return { netCash, thisMonthSpend, totalBudget, budgetRemaining };
}

export function getCategoryDonutData(month: string = CURRENT_MONTH) {
  const categoryMap = getCategoryMap();
  const items = getLineItems().filter((li) => inMonth(li.date, month) && li.amount < 0);
  const totals = new Map<string, number>();
  for (const li of items) {
    const cat = categoryMap.get(li.categoryId);
    if (!cat || cat.group === "Income") continue;
    totals.set(cat.id, (totals.get(cat.id) ?? 0) + -li.amount);
  }
  return Array.from(totals.entries())
    .map(([categoryId, amount]) => ({
      categoryId,
      name: categoryMap.get(categoryId)!.name,
      group: categoryMap.get(categoryId)!.group,
      amount,
    }))
    .sort((a, b) => b.amount - a.amount);
}

export function getMonthlyTrend(months: string[]) {
  const categoryMap = getCategoryMap();
  const items = getLineItems();
  return months.map((month) => {
    const monthItems = items.filter((li) => inMonth(li.date, month));
    let income = 0;
    let expense = 0;
    for (const li of monthItems) {
      const cat = categoryMap.get(li.categoryId);
      if (cat?.group === "Income") income += li.amount;
      else if (li.amount < 0) expense += -li.amount;
    }
    return { month, income, expense };
  });
}

export function getBudgetVsActual(month: string = CURRENT_MONTH) {
  const categoryMap = getCategoryMap();
  const budgets = all<BudgetRow>(`SELECT * FROM Budget WHERE month = ? ORDER BY amount DESC`, [month]);
  const items = getLineItems().filter((li) => inMonth(li.date, month) && li.amount < 0);
  const actualByCategory = new Map<string, number>();
  for (const li of items) {
    actualByCategory.set(li.categoryId, (actualByCategory.get(li.categoryId) ?? 0) + -li.amount);
  }
  return budgets.map((b) => ({
    categoryId: b.categoryId,
    name: categoryMap.get(b.categoryId)?.name ?? "Unknown",
    group: categoryMap.get(b.categoryId)?.group ?? "",
    budget: b.amount,
    actual: actualByCategory.get(b.categoryId) ?? 0,
  }));
}

export interface SankeyLink {
  source: string;
  target: string;
  value: number;
  color: string;
}

export function getSankeyData(month: string = CURRENT_MONTH) {
  const categoryMap = getCategoryMap();
  const items = getLineItems().filter((li) => inMonth(li.date, month));

  let totalIncome = 0;
  const spendBySplit = new Map<SplitType, number>();
  const spendByCategoryPerSplit = new Map<string, Map<string, number>>(); // splitType -> categoryId -> amount

  for (const li of items) {
    const cat = categoryMap.get(li.categoryId);
    if (!cat) continue;
    if (cat.group === "Income") {
      totalIncome += li.amount;
      continue;
    }
    if (li.amount >= 0) continue;
    const amt = -li.amount;
    spendBySplit.set(li.splitType, (spendBySplit.get(li.splitType) ?? 0) + amt);
    if (!spendByCategoryPerSplit.has(li.splitType)) spendByCategoryPerSplit.set(li.splitType, new Map());
    const byCat = spendByCategoryPerSplit.get(li.splitType)!;
    byCat.set(li.categoryId, (byCat.get(li.categoryId) ?? 0) + amt);
  }

  const totalSpend = Array.from(spendBySplit.values()).reduce((a, b) => a + b, 0);
  const savings = Math.max(0, totalIncome - totalSpend);

  return { totalIncome, totalSpend, savings, spendBySplit, spendByCategoryPerSplit, categoryMap };
}

export function getRecentTransactions(limit = 8) {
  const txns = all<TransactionRow>(`SELECT * FROM "Transaction" ORDER BY date DESC, rowid DESC LIMIT ?`, [limit]);
  const categoryMap = getCategoryMap();
  const receiptMap = getReceiptMap();
  return txns.map((t) => ({
    ...t,
    categoryName: categoryMap.get(t.categoryId)?.name ?? "Unknown",
    receiptUrl: t.receiptId ? receiptMap.get(t.receiptId)?.driveFileUrl ?? null : null,
  }));
}

export interface LedgerFilters {
  splitType?: string;
  categoryId?: string;
  search?: string;
  dateFrom?: string;
  dateTo?: string;
}

export function getLedgerTransactions(filters: LedgerFilters) {
  const categoryMap = getCategoryMap();
  const receiptMap = getReceiptMap();
  const accounts = new Map(getAccounts().map((a) => [a.id, a]));
  const splits = all<TransactionSplitRow>(`SELECT * FROM TransactionSplit`);
  const splitsByParent = new Map<string, TransactionSplitRow[]>();
  for (const s of splits) {
    const arr = splitsByParent.get(s.parentTransactionId) ?? [];
    arr.push(s);
    splitsByParent.set(s.parentTransactionId, arr);
  }

  let txns = all<TransactionRow>(`SELECT * FROM "Transaction" ORDER BY date DESC, rowid DESC`);

  if (filters.splitType) txns = txns.filter((t) => t.splitType === filters.splitType);
  if (filters.categoryId) txns = txns.filter((t) => t.categoryId === filters.categoryId);
  if (filters.dateFrom) txns = txns.filter((t) => t.date >= filters.dateFrom!);
  if (filters.dateTo) txns = txns.filter((t) => t.date <= filters.dateTo!);
  if (filters.search) {
    const q = filters.search.toLowerCase();
    txns = txns.filter((t) => t.merchant.toLowerCase().includes(q));
  }

  return txns.map((t) => {
    const children = splitsByParent.get(t.id) ?? [];
    return {
      ...t,
      categoryName: categoryMap.get(t.categoryId)?.name ?? "Unknown",
      accountName: accounts.get(t.accountId)?.name ?? "Unknown",
      receiptUrl: t.receiptId ? receiptMap.get(t.receiptId)?.driveFileUrl ?? null : null,
      splits: children.map((s) => ({
        ...s,
        categoryName: categoryMap.get(s.categoryId)?.name ?? "Unknown",
      })),
    };
  });
}
