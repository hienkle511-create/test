export type SplitType = "JOINT" | "PERSONAL_KRISSY" | "PERSONAL_HUSBAND" | "BABY";

export const SPLIT_COLORS: Record<SplitType, string> = {
  JOINT: "#22c55e",
  BABY: "#3b82f6",
  PERSONAL_KRISSY: "#c084fc",
  PERSONAL_HUSBAND: "#a855f7",
};

export const SPLIT_LABELS: Record<SplitType, string> = {
  JOINT: "Joint",
  BABY: "Baby",
  PERSONAL_KRISSY: "Personal (Krissy)",
  PERSONAL_HUSBAND: "Personal (Husband)",
};

// Soft background tint for badges, derived per split type.
export const SPLIT_BG: Record<SplitType, string> = {
  JOINT: "#dcfce7",
  BABY: "#dbeafe",
  PERSONAL_KRISSY: "#f3e8ff",
  PERSONAL_HUSBAND: "#ede9fe",
};

export interface CategoryRow {
  id: string;
  householdId: string;
  name: string;
  group: string;
}

export interface AccountRow {
  id: string;
  householdId: string;
  name: string;
  type: string;
  balance: number;
}

export interface TransactionRow {
  id: string;
  accountId: string;
  date: string;
  merchant: string;
  amount: number;
  categoryId: string;
  splitType: SplitType;
  notes: string | null;
  receiptId: string | null;
}

export interface TransactionSplitRow {
  id: string;
  parentTransactionId: string;
  description: string;
  amount: number;
  categoryId: string;
  splitType: SplitType;
  classificationSource: "rule" | "llm" | "manual";
}

export interface ReceiptRow {
  id: string;
  source: string;
  gmailMessageId: string | null;
  driveFileId: string | null;
  driveFileUrl: string | null;
  importedAt: string;
}

export interface BudgetRow {
  id: string;
  categoryId: string;
  month: string;
  amount: number;
}
