import React from "react";
import { Shell } from "../layout/Shell.tsx";
import { Card } from "../components/Card.tsx";
import { SplitBadge } from "../components/SplitBadge.tsx";
import { BudgetProgressRow } from "../components/BudgetProgress.tsx";
import { Donut } from "../charts/Donut.tsx";
import { TrendLine } from "../charts/TrendLine.tsx";
import { Sankey } from "../charts/Sankey.tsx";
import { ReceiptIcon, ExternalLinkIcon } from "../components/icons.tsx";
import { formatCurrency, formatDate, monthLabel } from "../lib/format.ts";
import {
  CURRENT_MONTH,
  getBudgetVsActual,
  getCategoryDonutData,
  getMonthlyTrend,
  getRecentTransactions,
  getSankeyData,
  getSummaryCards,
} from "../lib/queries.ts";

const TREND_MONTHS = ["2026-03", "2026-04", "2026-05", "2026-06", "2026-07", "2026-08"];

export function Dashboard() {
  const summary = getSummaryCards(CURRENT_MONTH);
  const donutData = getCategoryDonutData(CURRENT_MONTH);
  const trend = getMonthlyTrend(TREND_MONTHS);
  const sankey = getSankeyData(CURRENT_MONTH);
  const budgetVsActual = getBudgetVsActual(CURRENT_MONTH);
  const recent = getRecentTransactions(8);

  return (
    <Shell active="/" title="Dashboard" subtitle={`Overview for ${monthLabel(CURRENT_MONTH)}`}>
      <div className="stack">
        <div className="grid grid-cols-3">
          <Card>
            <div className="summary-card">
              <div className="summary-card-label">Net Cash</div>
              <div className={`summary-card-value ${summary.netCash >= 0 ? "positive" : "negative"}`}>
                {formatCurrency(summary.netCash)}
              </div>
              <div className="summary-card-sub">Across all accounts</div>
            </div>
          </Card>
          <Card>
            <div className="summary-card">
              <div className="summary-card-label">This Month Spend</div>
              <div className="summary-card-value">{formatCurrency(summary.thisMonthSpend)}</div>
              <div className="summary-card-sub">{monthLabel(CURRENT_MONTH)} so far</div>
            </div>
          </Card>
          <Card>
            <div className="summary-card">
              <div className="summary-card-label">Budget Remaining</div>
              <div className={`summary-card-value ${summary.budgetRemaining >= 0 ? "positive" : "negative"}`}>
                {formatCurrency(summary.budgetRemaining)}
              </div>
              <div className="summary-card-sub">of {formatCurrency(summary.totalBudget)} budgeted</div>
            </div>
          </Card>
        </div>

        <div className="grid grid-cols-12">
          <div className="col-span-7">
            <Card title="Spending by Category">
              <Donut data={donutData} />
            </Card>
          </div>
          <div className="col-span-5">
            <Card title="Income vs. Expense (6mo)">
              <TrendLine data={trend} />
              <div className="legend mt-4">
                <span className="legend-item">
                  <span className="legend-swatch" style={{ background: "#22c55e" }} /> Income
                </span>
                <span className="legend-item">
                  <span className="legend-swatch" style={{ background: "#f59e0b" }} /> Expense
                </span>
              </div>
            </Card>
          </div>
        </div>

        <Card title="Cash Flow" right={<span className="text-xs muted">Income → split → category</span>}>
          <Sankey
            totalIncome={sankey.totalIncome}
            savings={sankey.savings}
            spendBySplit={sankey.spendBySplit}
            spendByCategoryPerSplit={sankey.spendByCategoryPerSplit}
            categoryMap={sankey.categoryMap}
          />
        </Card>

        <div className="grid grid-cols-12">
          <div className="col-span-7">
            <Card title="Budget vs. Actual">
              {budgetVsActual.slice(0, 6).map((b) => (
                <BudgetProgressRow key={b.categoryId} name={b.name} budget={b.budget} actual={b.actual} />
              ))}
            </Card>
          </div>
          <div className="col-span-5">
            <Card title="Recent Transactions" right={<a href="/transactions" className="text-xs muted">View all</a>}>
              <table className="table">
                <tbody>
                  {recent.map((t) => (
                    <tr key={t.id} className="row-hover">
                      <td>
                        <div className="table-merchant">
                          {t.merchant}
                          {t.receiptUrl ? (
                            <a href={t.receiptUrl} target="_blank" rel="noreferrer" className="receipt-link" title="View receipt">
                              <ReceiptIcon size={13} />
                            </a>
                          ) : null}
                        </div>
                        <div className="text-xs muted">{formatDate(t.date)} · {t.categoryName}</div>
                      </td>
                      <td>
                        <SplitBadge splitType={t.splitType} />
                      </td>
                      <td className={`table-amount ${t.amount < 0 ? "negative" : "positive"}`}>
                        {formatCurrency(t.amount)}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </Card>
          </div>
        </div>
      </div>
    </Shell>
  );
}
