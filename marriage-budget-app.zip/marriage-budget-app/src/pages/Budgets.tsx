import React from "react";
import { Shell } from "../layout/Shell.tsx";
import { Card } from "../components/Card.tsx";
import { BudgetProgressRow, budgetStatus } from "../components/BudgetProgress.tsx";
import { formatCurrency, monthLabel } from "../lib/format.ts";
import { CURRENT_MONTH, getBudgetVsActual } from "../lib/queries.ts";

export function BudgetsPage() {
  const rows = getBudgetVsActual(CURRENT_MONTH);
  const byGroup = new Map<string, typeof rows>();
  for (const r of rows) {
    const arr = byGroup.get(r.group) ?? [];
    arr.push(r);
    byGroup.set(r.group, arr);
  }

  const totalBudget = rows.reduce((s, r) => s + r.budget, 0);
  const totalActual = rows.reduce((s, r) => s + r.actual, 0);
  const overCount = rows.filter((r) => budgetStatus(r.actual, r.budget) === "red").length;
  const nearCount = rows.filter((r) => budgetStatus(r.actual, r.budget) === "amber").length;

  const groupOrder = ["Household", "Baby", "Personal", "Income"];
  const groups = Array.from(byGroup.keys()).sort((a, b) => groupOrder.indexOf(a) - groupOrder.indexOf(b));

  return (
    <Shell active="/budgets" title="Budgets" subtitle={`${monthLabel(CURRENT_MONTH)} · ${rows.length} budgeted categories`}>
      <div className="stack">
        <div className="grid grid-cols-3">
          <Card>
            <div className="summary-card">
              <div className="summary-card-label">Total Budgeted</div>
              <div className="summary-card-value">{formatCurrency(totalBudget)}</div>
            </div>
          </Card>
          <Card>
            <div className="summary-card">
              <div className="summary-card-label">Total Spent</div>
              <div className={`summary-card-value ${totalActual > totalBudget ? "negative" : ""}`}>{formatCurrency(totalActual)}</div>
            </div>
          </Card>
          <Card>
            <div className="summary-card">
              <div className="summary-card-label">Status</div>
              <div className="summary-card-value" style={{ fontSize: 20 }}>
                {overCount > 0 ? (
                  <span style={{ color: "#b91c1c" }}>{overCount} over budget</span>
                ) : nearCount > 0 ? (
                  <span style={{ color: "#b45309" }}>{nearCount} near limit</span>
                ) : (
                  <span style={{ color: "#15803d" }}>On track</span>
                )}
              </div>
            </div>
          </Card>
        </div>

        {groups.map((g) => (
          <Card key={g} title={`${g} Budgets`}>
            {(byGroup.get(g) ?? []).map((r) => (
              <BudgetProgressRow key={r.categoryId} name={r.name} budget={r.budget} actual={r.actual} />
            ))}
          </Card>
        ))}
      </div>
    </Shell>
  );
}
