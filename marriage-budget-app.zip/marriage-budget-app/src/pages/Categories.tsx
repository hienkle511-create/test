import React from "react";
import { Shell } from "../layout/Shell.tsx";
import { PencilIcon, TrashIcon, PlusIcon } from "../components/icons.tsx";
import { getCategories, getCategoryDonutData, CURRENT_MONTH } from "../lib/queries.ts";
import { formatCurrency } from "../lib/format.ts";

const GROUP_COLORS: Record<string, string> = {
  Household: "#22c55e",
  Baby: "#3b82f6",
  Personal: "#c084fc",
  Income: "#94a3b8",
};

export function CategoriesPage() {
  const categories = getCategories();
  const spend = getCategoryDonutData(CURRENT_MONTH);
  const spendMap = new Map(spend.map((s) => [s.categoryId, s.amount]));

  const byGroup = new Map<string, typeof categories>();
  for (const c of categories) {
    const arr = byGroup.get(c.group) ?? [];
    arr.push(c);
    byGroup.set(c.group, arr);
  }
  const groupOrder = ["Household", "Baby", "Personal", "Income"];
  const groups = Array.from(byGroup.keys()).sort((a, b) => groupOrder.indexOf(a) - groupOrder.indexOf(b));

  return (
    <Shell
      active="/categories"
      title="Categories"
      subtitle={`${categories.length} categories across ${groups.length} groups`}
      headerRight={
        <button className="btn btn-primary" id="add-category-btn" type="button">
          <PlusIcon size={14} /> Add category
        </button>
      }
    >
      {groups.map((g) => (
        <div className="category-group" key={g} data-group={g}>
          <div className="category-group-title">
            <span className="category-group-dot" style={{ background: GROUP_COLORS[g] ?? "#9aa1b1" }} />
            {g}
          </div>
          <div className="category-cards" data-group-cards={g}>
            {(byGroup.get(g) ?? []).map((c) => (
              <div className="category-card" key={c.id} data-category-id={c.id}>
                <div>
                  <div className="category-card-name">{c.name}</div>
                  <div className="category-card-meta">
                    {spendMap.has(c.id) ? `${formatCurrency(spendMap.get(c.id)!)} this month` : "No spend this month"}
                  </div>
                </div>
                <div className="category-card-actions">
                  <button className="icon-btn edit-category-btn" type="button" title="Edit (demo — not saved)">
                    <PencilIcon />
                  </button>
                  <button className="icon-btn delete-category-btn" type="button" title="Delete (demo — not saved)">
                    <TrashIcon />
                  </button>
                </div>
              </div>
            ))}
            <button className="new-category-card" type="button" data-add-to-group={g}>
              <PlusIcon size={13} /> New in {g}
            </button>
          </div>
        </div>
      ))}
      <div className="toast" id="toast"></div>
    </Shell>
  );
}
