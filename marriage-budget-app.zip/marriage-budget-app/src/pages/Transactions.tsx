import React from "react";
import { Shell } from "../layout/Shell.tsx";
import { Card } from "../components/Card.tsx";
import { SplitBadge } from "../components/SplitBadge.tsx";
import { ReceiptIcon, SearchIcon, ChevronRightIcon } from "../components/icons.tsx";
import { formatCurrency, formatDate } from "../lib/format.ts";
import { getCategories, getLedgerTransactions, type LedgerFilters } from "../lib/queries.ts";
import type { SplitType } from "../types.ts";

const SPLIT_OPTIONS: { value: SplitType; label: string }[] = [
  { value: "JOINT", label: "Joint" },
  { value: "BABY", label: "Baby" },
  { value: "PERSONAL_KRISSY", label: "Personal (Krissy)" },
  { value: "PERSONAL_HUSBAND", label: "Personal (Husband)" },
];

export function TransactionsPage({ filters }: { filters: LedgerFilters }) {
  const categories = getCategories();
  const txns = getLedgerTransactions(filters);

  return (
    <Shell active="/transactions" title="Transactions" subtitle={`${txns.length} transaction${txns.length === 1 ? "" : "s"}`}>
      <Card>
        <form method="GET" action="/transactions" id="filter-form" className="filter-bar">
          <div className="input input-search" style={{ display: "flex", alignItems: "center", gap: 6, padding: "0 10px" }}>
            <SearchIcon size={14} />
            <input
              type="text"
              name="search"
              placeholder="Search merchant..."
              defaultValue={filters.search ?? ""}
              style={{ border: "none", outline: "none", padding: "9px 0", fontSize: 13, width: "100%", background: "transparent" }}
            />
          </div>

          <select className="select" name="splitType" defaultValue={filters.splitType ?? ""}>
            <option value="">All split types</option>
            {SPLIT_OPTIONS.map((s) => (
              <option key={s.value} value={s.value}>{s.label}</option>
            ))}
          </select>

          <select className="select" name="categoryId" defaultValue={filters.categoryId ?? ""}>
            <option value="">All categories</option>
            {categories.map((c) => (
              <option key={c.id} value={c.id}>{c.name}</option>
            ))}
          </select>

          <input className="input" type="date" name="dateFrom" defaultValue={filters.dateFrom ?? ""} />
          <span className="muted text-xs">to</span>
          <input className="input" type="date" name="dateTo" defaultValue={filters.dateTo ?? ""} />

          <button className="btn btn-primary" type="submit">Apply filters</button>
          {(filters.search || filters.splitType || filters.categoryId || filters.dateFrom || filters.dateTo) ? (
            <a className="btn" href="/transactions">Clear</a>
          ) : null}
        </form>

        <table className="table">
          <thead>
            <tr>
              <th style={{ width: 28 }}></th>
              <th>Merchant</th>
              <th>Date</th>
              <th>Category</th>
              <th>Account</th>
              <th>Split</th>
              <th style={{ textAlign: "right" }}>Amount</th>
            </tr>
          </thead>
          <tbody>
            {txns.length === 0 ? (
              <tr>
                <td colSpan={7}>
                  <div className="empty-state">No transactions match these filters.</div>
                </td>
              </tr>
            ) : null}
            {txns.map((t) => {
              const hasSplits = t.splits.length > 0;
              return (
                <React.Fragment key={t.id}>
                  <tr className="row-hover" data-parent-row={t.id}>
                    <td>
                      {hasSplits ? (
                        <button type="button" className="expand-toggle" data-toggle={t.id} aria-label="Expand splits">
                          <ChevronRightIcon size={14} />
                        </button>
                      ) : null}
                    </td>
                    <td>
                      <div className="table-merchant">
                        {t.merchant}
                        {t.receiptUrl ? (
                          <a href={t.receiptUrl} target="_blank" rel="noreferrer" className="receipt-link" title="View receipt in Drive">
                            <ReceiptIcon size={13} />
                          </a>
                        ) : null}
                      </div>
                      {hasSplits ? <div className="text-xs muted">Itemized · {t.splits.length} items</div> : null}
                    </td>
                    <td className="muted">{formatDate(t.date)}</td>
                    <td>{t.categoryName}</td>
                    <td className="muted">{t.accountName}</td>
                    <td><SplitBadge splitType={t.splitType} /></td>
                    <td className={`table-amount ${t.amount < 0 ? "negative" : "positive"}`}>{formatCurrency(t.amount)}</td>
                  </tr>
                  {hasSplits
                    ? t.splits.map((s) => (
                        <tr key={s.id} className="split-row hidden-row" data-child-of={t.id}>
                          <td></td>
                          <td colSpan={2} style={{ paddingLeft: 30 }}>↳ {s.description}</td>
                          <td>{s.categoryName}</td>
                          <td></td>
                          <td><SplitBadge splitType={s.splitType} /></td>
                          <td className="table-amount negative">{formatCurrency(s.amount)}</td>
                        </tr>
                      ))
                    : null}
                </React.Fragment>
              );
            })}
          </tbody>
        </table>
      </Card>
    </Shell>
  );
}
