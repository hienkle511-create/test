// Progressive-enhancement script for the Transactions ledger: expands /
// collapses itemized receipt splits under a parent transaction row.
document.addEventListener("DOMContentLoaded", () => {
  const toggles = document.querySelectorAll<HTMLButtonElement>("[data-toggle]");
  toggles.forEach((btn) => {
    btn.addEventListener("click", () => {
      const id = btn.getAttribute("data-toggle");
      if (!id) return;
      const rows = document.querySelectorAll<HTMLTableRowElement>(`[data-child-of="${id}"]`);
      const willOpen = rows.length > 0 && rows[0].classList.contains("hidden-row");
      rows.forEach((r) => r.classList.toggle("hidden-row", !willOpen));
      btn.classList.toggle("open", willOpen);
    });
  });
});
