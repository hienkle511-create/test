// Progressive-enhancement script for the Categories page. Add/edit/delete
// are intentionally non-persisting stubs (per the task scope) — they update
// the DOM only and surface a toast saying so; nothing is written to the DB.
function showToast(msg: string) {
  const toast = document.getElementById("toast");
  if (!toast) return;
  toast.textContent = msg;
  toast.classList.add("visible");
  window.setTimeout(() => toast.classList.remove("visible"), 2200);
}

function makeCard(name: string): HTMLDivElement {
  const card = document.createElement("div");
  card.className = "category-card";
  card.innerHTML = `
    <div>
      <div class="category-card-name">${name}</div>
      <div class="category-card-meta">No spend this month</div>
    </div>
    <div class="category-card-actions">
      <button class="icon-btn edit-category-btn" type="button" title="Edit (demo — not saved)">✎</button>
      <button class="icon-btn delete-category-btn" type="button" title="Delete (demo — not saved)">🗑</button>
    </div>`;
  return card;
}

document.addEventListener("DOMContentLoaded", () => {
  document.body.addEventListener("click", (e) => {
    const target = e.target as HTMLElement;

    const addBtn = target.closest("#add-category-btn");
    if (addBtn) {
      const name = window.prompt("New category name:");
      if (name && name.trim()) {
        const firstGroupCards = document.querySelector<HTMLElement>("[data-group-cards]");
        const addCardBtn = firstGroupCards?.querySelector(".new-category-card");
        if (firstGroupCards && addCardBtn) {
          firstGroupCards.insertBefore(makeCard(name.trim()), addCardBtn);
          bindCardButtons();
          showToast(`"${name.trim()}" added — demo only, not saved.`);
        }
      }
      return;
    }

    const groupAddBtn = target.closest<HTMLElement>("[data-add-to-group]");
    if (groupAddBtn) {
      const name = window.prompt("New category name:");
      if (name && name.trim()) {
        groupAddBtn.parentElement?.insertBefore(makeCard(name.trim()), groupAddBtn);
        bindCardButtons();
        showToast(`"${name.trim()}" added — demo only, not saved.`);
      }
      return;
    }
  });

  bindCardButtons();
});

function bindCardButtons() {
  document.querySelectorAll<HTMLButtonElement>(".edit-category-btn").forEach((btn) => {
    if (btn.dataset.bound) return;
    btn.dataset.bound = "1";
    btn.addEventListener("click", () => {
      const card = btn.closest(".category-card");
      const nameEl = card?.querySelector(".category-card-name");
      if (!nameEl) return;
      const next = window.prompt("Rename category:", nameEl.textContent ?? "");
      if (next && next.trim()) {
        nameEl.textContent = next.trim();
        showToast("Renamed — demo only, not saved.");
      }
    });
  });
  document.querySelectorAll<HTMLButtonElement>(".delete-category-btn").forEach((btn) => {
    if (btn.dataset.bound) return;
    btn.dataset.bound = "1";
    btn.addEventListener("click", () => {
      const card = btn.closest(".category-card");
      if (card && window.confirm("Remove this category from view? (demo only, not saved)")) {
        card.remove();
        showToast("Removed — demo only, not saved.");
      }
    });
  });
}
