// ---------------------------------------------------------------------------
// Marriage Budget App — application server.
//
// This project was specced as a Next.js 14 App Router app, but this sandbox
// has no route to the npm registry (registry.npmjs.org, jsr.io, unpkg,
// jsdelivr, GitHub codeload, apt, and pypi are all network-egress-denied for
// this session — verified directly, not assumed), so `next`, `react` (a
// project-local copy), `prisma`, `tailwindcss`, `shadcn/ui`, `recharts`, and
// `d3-sankey` could not be installed. To still deliver a real, running app
// rather than a mockup, this server hand-implements the same architecture
// Next's App Router would give us — file-per-route pages, a shared layout,
// server-rendered React, a tiny bundled client script per page for
// progressive-enhancement interactivity — using only what's available
// locally in this sandbox image: the `react`/`react-dom` packages already
// installed globally for other Claude tooling, TypeScript, esbuild
// (bundled inside the globally-installed `tsx`), and Node's built-in
// `node:sqlite` and `http` modules. See prisma/schema.prisma and
// public/styles.css for the equivalent notes on the data layer and styling.
import http from "node:http";
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";
import React from "react";
import { renderToStaticMarkup } from "react-dom/server";

import { Document } from "./layout/Document.tsx";
import { Dashboard } from "./pages/Dashboard.tsx";
import { TransactionsPage } from "./pages/Transactions.tsx";
import { BudgetsPage } from "./pages/Budgets.tsx";
import { CategoriesPage } from "./pages/Categories.tsx";
import type { LedgerFilters } from "./lib/queries.ts";

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const PUBLIC_DIR = path.join(__dirname, "..", "public");
const PORT = Number(process.env.PORT ?? 3000);

const MIME: Record<string, string> = {
  ".css": "text/css",
  ".js": "text/javascript",
  ".svg": "image/svg+xml",
  ".png": "image/png",
  ".ico": "image/x-icon",
};

function renderPage(element: React.ReactElement) {
  return "<!doctype html>" + renderToStaticMarkup(element);
}

function serveStatic(req: any, res: any, pathname: string): boolean {
  const filePath = path.join(PUBLIC_DIR, pathname);
  if (!filePath.startsWith(PUBLIC_DIR)) return false;
  if (!fs.existsSync(filePath) || fs.statSync(filePath).isDirectory()) return false;
  const ext = path.extname(filePath);
  res.writeHead(200, { "Content-Type": MIME[ext] ?? "application/octet-stream" });
  fs.createReadStream(filePath).pipe(res);
  return true;
}

const server = http.createServer((req: any, res: any) => {
  try {
    const url = new URL(req.url ?? "/", `http://${req.headers.host ?? "localhost"}`);
    const pathname = url.pathname;

    if (pathname !== "/" && serveStatic(req, res, pathname)) return;

    let html: string | null = null;

    if (pathname === "/") {
      html = renderPage(<Document title="Dashboard"><Dashboard /></Document>);
    } else if (pathname === "/transactions") {
      const filters: LedgerFilters = {
        splitType: url.searchParams.get("splitType") || undefined,
        categoryId: url.searchParams.get("categoryId") || undefined,
        search: url.searchParams.get("search") || undefined,
        dateFrom: url.searchParams.get("dateFrom") || undefined,
        dateTo: url.searchParams.get("dateTo") || undefined,
      };
      html = renderPage(
        <Document title="Transactions" clientScript="/transactions.js">
          <TransactionsPage filters={filters} />
        </Document>
      );
    } else if (pathname === "/budgets") {
      html = renderPage(<Document title="Budgets"><BudgetsPage /></Document>);
    } else if (pathname === "/categories") {
      html = renderPage(
        <Document title="Categories" clientScript="/categories.js">
          <CategoriesPage />
        </Document>
      );
    }

    if (html) {
      res.writeHead(200, { "Content-Type": "text/html; charset=utf-8" });
      res.end(html);
      return;
    }

    res.writeHead(404, { "Content-Type": "text/plain" });
    res.end("Not found");
  } catch (err) {
    console.error(err);
    res.writeHead(500, { "Content-Type": "text/plain" });
    res.end("Internal server error\n" + (err instanceof Error ? err.stack : String(err)));
  }
});

server.listen(PORT, () => {
  console.log(`Marriage Budget App listening on http://localhost:${PORT}`);
});
