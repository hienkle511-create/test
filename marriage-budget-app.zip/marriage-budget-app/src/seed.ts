// Seed script: populates dev.db with a realistic ~6-month household history.
// Run with: npm run seed  (tsx src/seed.ts)
import { db, initSchema } from "./db.ts";
import crypto from "node:crypto";

function id(prefix: string) {
  return `${prefix}_${crypto.randomBytes(6).toString("hex")}`;
}

// Reset all tables for a clean, idempotent seed.
function resetTables() {
  const tables = [
    "TransactionSplit",
    "Transaction",
    "Budget",
    "Receipt",
    "Category",
    "Account",
    "User",
    "Household",
  ];
  for (const t of tables) db.exec(`DELETE FROM "${t}";`);
}

initSchema();
resetTables();

// ---------------------------------------------------------------------------
// Household & users
// ---------------------------------------------------------------------------
const householdId = id("hh");
db.prepare(`INSERT INTO Household (id, name) VALUES (?, ?)`).run(householdId, "The Household Budget");

const krissyId = id("usr");
const husbandId = id("usr");
db.prepare(`INSERT INTO User (id, householdId, name, email, displayColor) VALUES (?, ?, ?, ?, ?)`).run(
  krissyId, householdId, "Krissy", "krissy@example.com", "#c084fc"
);
db.prepare(`INSERT INTO User (id, householdId, name, email, displayColor) VALUES (?, ?, ?, ?, ?)`).run(
  husbandId, householdId, "Husband", "husband@example.com", "#a855f7"
);

// ---------------------------------------------------------------------------
// Categories
// ---------------------------------------------------------------------------
type CatSeed = { key: string; name: string; group: string };
const CATS: CatSeed[] = [
  { key: "paycheck", name: "Paycheck", group: "Income" },
  { key: "bonus", name: "Bonus / Other Income", group: "Income" },
  { key: "groceries", name: "Groceries", group: "Household" },
  { key: "utilities", name: "Utilities", group: "Household" },
  { key: "essentials", name: "Household Essentials", group: "Household" },
  { key: "rent", name: "Rent/Mortgage", group: "Household" },
  { key: "dining", name: "Dining", group: "Household" },
  { key: "subscriptions", name: "Subscriptions", group: "Household" },
  { key: "transportation", name: "Transportation", group: "Household" },
  { key: "babysupplies", name: "Baby Supplies", group: "Baby" },
  { key: "childcare", name: "Childcare", group: "Baby" },
  { key: "personalcare", name: "Personal Care", group: "Personal" },
  { key: "shopping", name: "Shopping", group: "Personal" },
  { key: "entertainment", name: "Entertainment", group: "Personal" },
];
const catIds: Record<string, string> = {};
for (const c of CATS) {
  const cid = id("cat");
  catIds[c.key] = cid;
  db.prepare(`INSERT INTO Category (id, householdId, name, "group") VALUES (?, ?, ?, ?)`).run(
    cid, householdId, c.name, c.group
  );
}

// ---------------------------------------------------------------------------
// Accounts
// ---------------------------------------------------------------------------
const checkingId = id("acc");
const creditId = id("acc");
const savingsId = id("acc");
db.prepare(`INSERT INTO Account (id, householdId, name, type, balance) VALUES (?, ?, ?, ?, ?)`).run(
  checkingId, householdId, "Joint Checking", "checking", 8420.55
);
db.prepare(`INSERT INTO Account (id, householdId, name, type, balance) VALUES (?, ?, ?, ?, ?)`).run(
  creditId, householdId, "Joint Credit Card", "credit", -1284.12
);
db.prepare(`INSERT INTO Account (id, householdId, name, type, balance) VALUES (?, ?, ?, ?, ?)`).run(
  savingsId, householdId, "Household Savings", "cash", 15230.0
);

// ---------------------------------------------------------------------------
// Transactions
// ---------------------------------------------------------------------------
const MONTHS = ["2026-03", "2026-04", "2026-05", "2026-06", "2026-07", "2026-08"];
const isCurrentMonth = (m: string) => m === "2026-08";

function insertTxn(opts: {
  date: string;
  merchant: string;
  amount: number;
  categoryKey: string;
  splitType: string;
  accountId?: string;
  notes?: string | null;
  receiptId?: string | null;
}) {
  const tid = id("txn");
  db.prepare(
    `INSERT INTO "Transaction" (id, accountId, date, merchant, amount, categoryId, splitType, notes, receiptId)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`
  ).run(
    tid,
    opts.accountId ?? checkingId,
    opts.date,
    opts.merchant,
    opts.amount,
    catIds[opts.categoryKey],
    opts.splitType,
    opts.notes ?? null,
    opts.receiptId ?? null
  );
  return tid;
}

let txnCount = 0;
const DINING_ROTATION: Array<"JOINT" | "PERSONAL_KRISSY" | "PERSONAL_HUSBAND"> = [
  "JOINT",
  "PERSONAL_KRISSY",
  "PERSONAL_HUSBAND",
];

MONTHS.forEach((m, idx) => {
  const current = isCurrentMonth(m);

  // --- Core recurring monthly items (dated within the first week so the
  // partial current month still has a full, realistic set) ---
  insertTxn({ date: `${m}-01`, merchant: "Acme Corp Payroll", amount: 4250.0, categoryKey: "paycheck", splitType: "JOINT" });
  txnCount++;
  insertTxn({ date: `${m}-01`, merchant: "Meridian Property Mgmt", amount: -2200.0, categoryKey: "rent", splitType: "JOINT" });
  txnCount++;
  insertTxn({ date: `${m}-02`, merchant: "Netflix", amount: -17.99, categoryKey: "subscriptions", splitType: "JOINT", accountId: creditId });
  txnCount++;
  insertTxn({ date: `${m}-02`, merchant: "Sunshine Daycare", amount: -900.0, categoryKey: "childcare", splitType: "BABY" });
  txnCount++;
  insertTxn({ date: `${m}-03`, merchant: "Trader Joe's", amount: -128.47, categoryKey: "groceries", splitType: "JOINT", accountId: creditId });
  txnCount++;
  insertTxn({ date: `${m}-04`, merchant: "Shell Gas Station", amount: -52.30, categoryKey: "transportation", splitType: "JOINT", accountId: creditId });
  txnCount++;
  insertTxn({ date: `${m}-05`, merchant: "City Power & Light", amount: -164.32, categoryKey: "utilities", splitType: "JOINT", accountId: creditId });
  txnCount++;
  insertTxn({ date: `${m}-06`, merchant: "Buy Buy Baby", amount: -63.55, categoryKey: "babysupplies", splitType: "BABY", accountId: creditId });
  txnCount++;
  insertTxn({
    date: `${m}-07`,
    merchant: "Local Bistro",
    amount: -68.4,
    categoryKey: "dining",
    splitType: DINING_ROTATION[idx % DINING_ROTATION.length],
    accountId: creditId,
  });
  txnCount++;

  // --- Sparser items: only in a subset of months, for variety without
  // ballooning the row count past the ~30-50 target ---
  if (!current && idx % 2 === 0) {
    insertTxn({
      date: `${m}-13`,
      merchant: idx % 4 === 0 ? "Glow Salon & Spa" : "Sport Clips",
      amount: idx % 4 === 0 ? -85.0 : -28.0,
      categoryKey: "personalcare",
      splitType: idx % 4 === 0 ? "PERSONAL_KRISSY" : "PERSONAL_HUSBAND",
      accountId: creditId,
    });
    txnCount++;
  }
  if (!current && idx % 3 === 1) {
    insertTxn({
      date: `${m}-16`,
      merchant: "Nordstrom",
      amount: -112.6,
      categoryKey: "shopping",
      splitType: "PERSONAL_KRISSY",
      accountId: creditId,
    });
    txnCount++;
  }
  if (!current && idx % 3 === 2) {
    insertTxn({
      date: `${m}-19`,
      merchant: "AMC Theatres",
      amount: -41.5,
      categoryKey: "entertainment",
      splitType: "JOINT",
      accountId: creditId,
    });
    txnCount++;
  }
});

// ---------------------------------------------------------------------------
// Receipts with itemized splits (simulated Target-style runs)
// ---------------------------------------------------------------------------
function insertReceipt(opts: {
  source: string;
  gmailMessageId?: string | null;
  driveFileId?: string | null;
  driveFileUrl?: string | null;
  importedAt: string;
}) {
  const rid = id("rcpt");
  db.prepare(
    `INSERT INTO Receipt (id, source, gmailMessageId, driveFileId, driveFileUrl, importedAt) VALUES (?, ?, ?, ?, ?, ?)`
  ).run(rid, opts.source, opts.gmailMessageId ?? null, opts.driveFileId ?? null, opts.driveFileUrl ?? null, opts.importedAt);
  return rid;
}

function insertSplit(opts: {
  parentTransactionId: string;
  description: string;
  amount: number;
  categoryKey: string;
  splitType: string;
  classificationSource: "rule" | "llm" | "manual";
}) {
  const sid = id("spl");
  db.prepare(
    `INSERT INTO TransactionSplit (id, parentTransactionId, description, amount, categoryId, splitType, classificationSource)
     VALUES (?, ?, ?, ?, ?, ?, ?)`
  ).run(sid, opts.parentTransactionId, opts.description, opts.amount, catIds[opts.categoryKey], opts.splitType, opts.classificationSource);
  return sid;
}

// Receipt 1: Target run in May — joint groceries + baby items + Krissy personal item.
// This one has the demo Drive link so the ledger UI can show the receipt-link feature.
{
  const receiptId = insertReceipt({
    source: "drive",
    driveFileId: "demo123",
    driveFileUrl: "https://drive.google.com/file/d/demo123/view",
    importedAt: "2026-05-09T14:32:00.000Z",
  });
  const parentAmount = -21.47 - 34.98 - 18.5;
  const parentId = insertTxn({
    date: "2026-05-09",
    merchant: "Target",
    amount: parentAmount,
    categoryKey: "essentials",
    splitType: "JOINT",
    accountId: creditId,
    notes: "Itemized receipt — see splits",
    receiptId,
  });
  txnCount++;
  insertSplit({ parentTransactionId: parentId, description: "Paper towels, cleaning supplies", amount: -21.47, categoryKey: "essentials", splitType: "JOINT", classificationSource: "llm" });
  insertSplit({ parentTransactionId: parentId, description: "Diapers & wipes", amount: -34.98, categoryKey: "babysupplies", splitType: "BABY", classificationSource: "llm" });
  insertSplit({ parentTransactionId: parentId, description: "Krissy — makeup", amount: -18.5, categoryKey: "personalcare", splitType: "PERSONAL_KRISSY", classificationSource: "llm" });
}

// Receipt 2: Target run in June — groceries + baby + husband personal item, no Drive link (Gmail-sourced).
{
  const receiptId = insertReceipt({
    source: "gmail",
    gmailMessageId: "18f2a9c7b3e4d5f6",
    importedAt: "2026-06-14T18:05:00.000Z",
  });
  const parentAmount = -46.12 - 27.85 - 22.0;
  const parentId = insertTxn({
    date: "2026-06-14",
    merchant: "Target",
    amount: parentAmount,
    categoryKey: "groceries",
    splitType: "JOINT",
    accountId: creditId,
    notes: "Itemized receipt — see splits",
    receiptId,
  });
  txnCount++;
  insertSplit({ parentTransactionId: parentId, description: "Groceries & snacks", amount: -46.12, categoryKey: "groceries", splitType: "JOINT", classificationSource: "llm" });
  insertSplit({ parentTransactionId: parentId, description: "Baby food & formula", amount: -27.85, categoryKey: "babysupplies", splitType: "BABY", classificationSource: "llm" });
  insertSplit({ parentTransactionId: parentId, description: "Husband — phone case", amount: -22.0, categoryKey: "shopping", splitType: "PERSONAL_HUSBAND", classificationSource: "manual" });
}

// Receipt 3: Target run in July — household essentials + baby + both spouses' personal items.
{
  const receiptId = insertReceipt({
    source: "drive",
    driveFileId: "demo456",
    driveFileUrl: "https://drive.google.com/file/d/demo456/view",
    importedAt: "2026-07-20T16:47:00.000Z",
  });
  const parentAmount = -19.99 - 41.2 - 15.75 - 12.49;
  const parentId = insertTxn({
    date: "2026-07-20",
    merchant: "Target",
    amount: parentAmount,
    categoryKey: "essentials",
    splitType: "JOINT",
    accountId: creditId,
    notes: "Itemized receipt — see splits",
    receiptId,
  });
  txnCount++;
  insertSplit({ parentTransactionId: parentId, description: "Laundry detergent, trash bags", amount: -19.99, categoryKey: "essentials", splitType: "JOINT", classificationSource: "rule" });
  insertSplit({ parentTransactionId: parentId, description: "Diapers (bulk pack)", amount: -41.2, categoryKey: "babysupplies", splitType: "BABY", classificationSource: "rule" });
  insertSplit({ parentTransactionId: parentId, description: "Krissy — skincare", amount: -15.75, categoryKey: "personalcare", splitType: "PERSONAL_KRISSY", classificationSource: "llm" });
  insertSplit({ parentTransactionId: parentId, description: "Husband — snacks", amount: -12.49, categoryKey: "dining", splitType: "PERSONAL_HUSBAND", classificationSource: "manual" });
}

// ---------------------------------------------------------------------------
// Budgets for the current month (2026-08)
// ---------------------------------------------------------------------------
const BUDGETS: { key: string; amount: number }[] = [
  { key: "groceries", amount: 550 },
  { key: "utilities", amount: 220 },
  { key: "essentials", amount: 150 },
  { key: "rent", amount: 2200 },
  { key: "dining", amount: 250 },
  { key: "subscriptions", amount: 60 },
  { key: "transportation", amount: 180 },
  { key: "babysupplies", amount: 200 },
  { key: "childcare", amount: 900 },
  { key: "personalcare", amount: 120 },
  { key: "shopping", amount: 150 },
  { key: "entertainment", amount: 100 },
];
for (const b of BUDGETS) {
  db.prepare(`INSERT INTO Budget (id, categoryId, month, amount) VALUES (?, ?, ?, ?)`).run(
    id("bud"), catIds[b.key], "2026-08", b.amount
  );
}

const totalTxns = db.prepare(`SELECT COUNT(*) as c FROM "Transaction"`).get() as { c: number };
const totalSplits = db.prepare(`SELECT COUNT(*) as c FROM TransactionSplit`).get() as { c: number };
console.log(`Seed complete: ${totalTxns.c} transactions, ${totalSplits.c} itemized splits, ${BUDGETS.length} budgets.`);
