import React from "react";
import { HomeIcon, ListIcon, WalletIcon, TagIcon } from "../components/icons.tsx";

const NAV = [
  { href: "/", label: "Dashboard", Icon: HomeIcon },
  { href: "/transactions", label: "Transactions", Icon: ListIcon },
  { href: "/budgets", label: "Budgets", Icon: WalletIcon },
  { href: "/categories", label: "Categories", Icon: TagIcon },
];

export function Sidebar({ active }: { active: string }) {
  return (
    <aside className="sidebar">
      <div className="sidebar-brand">
        <div className="sidebar-brand-mark" />
        <div>
          <div className="sidebar-brand-text">Our Budget</div>
          <div className="sidebar-brand-sub">Krissy &amp; Husband</div>
        </div>
      </div>
      <nav className="sidebar-nav">
        {NAV.map(({ href, label, Icon }) => (
          <a key={href} href={href} className={`sidebar-link${active === href ? " active" : ""}`}>
            <Icon />
            {label}
          </a>
        ))}
      </nav>
      <div className="sidebar-footer">
        <div className="avatar-pair">
          <div className="avatar" style={{ background: "#c084fc" }}>K</div>
          <div className="avatar" style={{ background: "#a855f7" }}>H</div>
        </div>
        <div className="sidebar-footer-text">
          Joint household
          <br />
          demo workspace
        </div>
      </div>
    </aside>
  );
}
