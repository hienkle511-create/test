import React from "react";

export function Document({
  title,
  children,
  clientScript,
}: {
  title: string;
  children: React.ReactNode;
  clientScript?: string;
}) {
  return (
    <html lang="en">
      <head>
        <meta charSet="utf-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1" />
        <title>{`${title} · Our Budget`}</title>
        <link rel="stylesheet" href="/styles.css" />
      </head>
      <body>
        <div id="root">{children}</div>
        {clientScript ? <script type="module" src={clientScript}></script> : null}
      </body>
    </html>
  );
}
