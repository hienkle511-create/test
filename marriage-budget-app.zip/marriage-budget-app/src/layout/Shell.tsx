import React from "react";
import { Sidebar } from "./Sidebar.tsx";

export function Shell({
  active,
  title,
  subtitle,
  headerRight,
  children,
}: {
  active: string;
  title: string;
  subtitle?: string;
  headerRight?: React.ReactNode;
  children: React.ReactNode;
}) {
  return (
    <div className="app-shell">
      <Sidebar active={active} />
      <main className="main">
        <div className="page-header">
          <div>
            <div className="page-title">{title}</div>
            {subtitle ? <div className="page-subtitle">{subtitle}</div> : null}
          </div>
          {headerRight}
        </div>
        {children}
      </main>
    </div>
  );
}
