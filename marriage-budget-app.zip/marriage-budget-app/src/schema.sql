-- Marriage Budget App — SQLite DDL
-- Mirrors prisma/schema.prisma. Executed at startup via src/db.ts using
-- Node's built-in node:sqlite driver (see note in prisma/schema.prisma on
-- why @prisma/client isn't used in this sandbox build).

CREATE TABLE IF NOT EXISTS Household (
  id   TEXT PRIMARY KEY,
  name TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS User (
  id           TEXT PRIMARY KEY,
  householdId  TEXT NOT NULL REFERENCES Household(id),
  name         TEXT NOT NULL,
  email        TEXT NOT NULL,
  displayColor TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS Category (
  id          TEXT PRIMARY KEY,
  householdId TEXT NOT NULL REFERENCES Household(id),
  name        TEXT NOT NULL,
  "group"     TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS Account (
  id          TEXT PRIMARY KEY,
  householdId TEXT NOT NULL REFERENCES Household(id),
  name        TEXT NOT NULL,
  type        TEXT NOT NULL,
  balance     REAL NOT NULL
);

CREATE TABLE IF NOT EXISTS Receipt (
  id             TEXT PRIMARY KEY,
  source         TEXT NOT NULL,
  gmailMessageId TEXT,
  driveFileId    TEXT,
  driveFileUrl   TEXT,
  importedAt     TEXT NOT NULL
);

-- SplitType: 'JOINT' | 'PERSONAL_KRISSY' | 'PERSONAL_HUSBAND' | 'BABY'
CREATE TABLE IF NOT EXISTS "Transaction" (
  id          TEXT PRIMARY KEY,
  accountId   TEXT NOT NULL REFERENCES Account(id),
  date        TEXT NOT NULL,
  merchant    TEXT NOT NULL,
  amount      REAL NOT NULL,
  categoryId  TEXT NOT NULL REFERENCES Category(id),
  splitType   TEXT NOT NULL,
  notes       TEXT,
  receiptId   TEXT REFERENCES Receipt(id)
);

-- classificationSource: 'rule' | 'llm' | 'manual'
CREATE TABLE IF NOT EXISTS TransactionSplit (
  id                   TEXT PRIMARY KEY,
  parentTransactionId  TEXT NOT NULL REFERENCES "Transaction"(id),
  description          TEXT NOT NULL,
  amount               REAL NOT NULL,
  categoryId           TEXT NOT NULL REFERENCES Category(id),
  splitType            TEXT NOT NULL,
  classificationSource TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS Budget (
  id         TEXT PRIMARY KEY,
  categoryId TEXT NOT NULL REFERENCES Category(id),
  month      TEXT NOT NULL,
  amount     REAL NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_txn_date ON "Transaction"(date);
CREATE INDEX IF NOT EXISTS idx_txn_category ON "Transaction"(categoryId);
CREATE INDEX IF NOT EXISTS idx_txn_split ON "Transaction"(splitType);
CREATE INDEX IF NOT EXISTS idx_split_parent ON TransactionSplit(parentTransactionId);
CREATE INDEX IF NOT EXISTS idx_budget_month ON Budget(month);
