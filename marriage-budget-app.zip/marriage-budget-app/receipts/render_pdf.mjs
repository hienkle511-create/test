import { chromium } from 'playwright-core';
import path from 'path';

const executablePath = '/opt/pw-browsers/chromium';
const browser = await chromium.launch({ executablePath });
const page = await browser.newPage();
const filePath = 'file://' + path.resolve('target_3967_coded.html');
await page.goto(filePath, { waitUntil: 'networkidle', timeout: 30000 }).catch(async () => {
  // fallback if networkidle times out due to remote images/tracking pixels
  await page.goto(filePath, { waitUntil: 'load', timeout: 30000 });
});
await page.pdf({ path: 'target_3967_coded.pdf', width: '700px', printBackground: true });
await page.screenshot({ path: 'target_3967_coded_preview.png', fullPage: true });
await browser.close();
console.log('done');
